#_______________ APP.PY _______________
# MAIN OF THE APPLICATION

from gui import initLaunchGui

def main():
    initLaunchGui()
    
main()

